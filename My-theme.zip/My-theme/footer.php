<?php
/**
 * The template for displaying the footer
 */

?>

</div><!-- #content -->

<!-- Footer -->
<footer class="page-footer font-small indigo site-footer"  id="colophon" style="background: #9f9b9b;">

		<!-- Footer Links -->
		<div class="container text-center text-md-left">

				<!-- Grid row -->
				<div class="row">

						<!-- Grid column -->
						<div class="col-md-3 mx-auto">

								<!-- Links -->
<!---->
<!---->
<!--                    --><?php //if ( has_nav_menu( 'footer' ) ) : ?>
<!---->
<!--                            --><?php
//                            wp_nav_menu(
//                                array(
//                                    'theme_location' => 'footer',
//                                    'menu_class'     => 'footer-menu',
//                                    'depth'          => 1,
//                                    'container' => false,
//                                    'menu_class' => 'list-unstyled'
//                                )
//                            );
//                            ?>
<!--										-->
<!--                    --><?php //endif; ?>
								</ul>

						</div>
						<!-- Grid column -->

						<hr class="clearfix w-100 d-md-none">

						<!-- Grid column -->
						<div class="col-md-3 mx-auto">



						</div>
						<!-- Grid column -->

						<hr class="clearfix w-100 d-md-none">

						<!-- Grid column -->
						<div class="col-md-3 mx-auto">


						</div>
						<!-- Grid column -->

						<hr class="clearfix w-100 d-md-none">

						<!-- Grid column -->
						<div class="col-md-3 mx-auto">



						</div>
						<!-- Grid column -->

				</div>
				<!-- Grid row -->

		</div>
		<!-- Footer Links -->

		<!-- Copyright -->
		<div class="footer-copyright text-center py-3"> <?php $blog_info = get_bloginfo( 'name' ); ?>
        <?php if ( ! empty( $blog_info ) ) : ?>
						<a class="site-name" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>,
        <?php endif; ?>
        <?php
        /* translators: %s: WordPress. */
        printf( __( 'Proudly powered by %s.', 'twentynineteen' ), 'WordPress' );
        ?>
				</a>
        <?php
        if ( function_exists( 'the_privacy_policy_link' ) ) {
            the_privacy_policy_link( '', '<span role="separator" aria-hidden="true"></span>' );
        }
        ?>
		</div>
		<!-- Copyright -->

</footer>
<!-- Footer -->

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>



