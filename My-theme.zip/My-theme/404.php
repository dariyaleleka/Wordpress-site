<?php get_header(); ?>
    <h2>Ошибка 404 - Не найдено</h2>
<?php get_sidebar(); ?>
<?php get_footer(); ?>