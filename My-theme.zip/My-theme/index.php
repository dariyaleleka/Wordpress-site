<?php
/**
 * The main template file
 *
 */

get_header();
?>
<div class="container">
		<div class="row">
				<div class="col-12">
						<h2 style="color: #fff;">Последние посты </h2>
				</div>
		</div>
</div>
		<div id="primary" class="content-area">
				<main id="main" class="site-main">
						<div class="container">
								<div class="row">
										<div class="col-12">
												<div class="video-cards">
            <?php
            if ( have_posts() ) {

                // Load posts loop.
                while ( have_posts() ) {
                     the_post();
                     get_template_part( 'template/content' );
                }


            }
            ?>
												</div>
										</div>
								</div>
						</div>


				</main><!-- .site-main -->
		</div><!-- .content-area -->


<?php
get_sidebar();
get_footer();

