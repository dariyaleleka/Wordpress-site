<?php
/**
 * Template part for displaying posts
 */

?>
<div class="container">
		<div class="row">
				<div class="col-12">
					<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

							<div class="entry-content">
                    <?php
                         the_title('<h2 class="article-post" style="color: #fff;"> ', ' <span class="badge bg-secondary">New</span></h2>');

                        echo get_the_post_thumbnail();

                         the_content();

                    ?>
							</div>

					</article>
				</div>
		</div>
</div>