<?php
/**
 * Template part for displaying posts
 */

?>


								<div class="card" style="width: 20rem;">
                    <?php echo get_the_post_thumbnail('', '', array('class' => 'card-img-top')); ?>
										<div class="card-body">
												<h5 class="card-title"><a href="<?php echo the_permalink() ?>"><?php echo the_title(); ?></h5>
												<p class="card-text"><?php echo the_content(); ?></p>
												<a href="<?php the_permalink() ?>" class="btn btn-primary">Read</a>
										</div>
								</div>

