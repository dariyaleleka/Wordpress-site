<?php
/**
 * Template part for displaying page content in page.php
 *
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

		<section class="hero" id="top">
				<div class="container">
						<div class="row">
								<div class="col-lg-12">
										<!--								<h1 class="display-3">I like it smooth</h1>-->
										<header class="entry-header">
                        <?php get_template_part( 'template/header/entry', 'header' ); ?>
										</header>
								</div>
						</div>
				</div>
		</section>

		<section class="features" id="features">
				<div class="container">
						<div class="row">
								<div class="col-md-8">
                    <?php the_content();

                    wp_link_pages(
                        array(
                            'before' => '<div class="page-links">' . __( 'Pages:', 'test-site' ),
                            'after'  => '</div>',
                        )
                    );

                    ?>
								</div>
								<div class="col-md-4">
										<?php  echo get_the_post_thumbnail();?>
								</div>
						</div>
				</div>
		</section>

</article><!-- #post-<?php the_ID(); ?> -->


