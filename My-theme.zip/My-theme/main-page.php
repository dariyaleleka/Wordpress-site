<?php
/*
Template Name: Шаблон страницы для вывода #3 - Стандартный
*/
get_header();

?>


контент 3

<?php get_footer(); ?>