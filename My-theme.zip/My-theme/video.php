<?php
/*
Template Name: Шаблон страницы для вывода #2 - Video
*/
get_header();

?>
		<div class="container">
		<div class="row">
		<div class="col-12">
		<div class="video-cards">

<?php
$args = array(
    'post_type' => 'video',
    'meta_key' => '_custom_post_order',
    'orderby' => 'meta_value',
    'order' => 'ASC'
);
$query = new WP_query ( $args );
if ( $query->have_posts() ) {
    while ($query->have_posts() ) {
        $query->the_post();

        if ( !empty(get_post_meta( $post->ID, '_custom_post_order', true )) ) : ?>

		        <div class="card" style="width: 20rem;">
                <?php echo get_the_post_thumbnail('', '', array('class' => 'card-img-top')); ?>
				        <div class="card-body">
						        <h5 class="card-title"><?php the_title(); ?></h5>
						        <p class="card-text"><?php the_content(); ?></p>
				        </div>
				        <div class="list-group list-group-flush">
							<span>
								 <h5>Жанры</h5>
                    			<?php echo wp_strip_all_tags( get_the_term_list( get_the_ID(), 'post_genre', ' ', ' , ', ' ') );   ?>
							</span>
							<span>
						
						        <h5>Языки</h5>
                    <?php echo wp_strip_all_tags( get_the_term_list( get_the_ID(), 'post_lang', ' ', ' , ', ' ') );   ?>
							</span>
						       
				        </div>
				        <div class="card-body">
						        <h5>Стоимость подписки:</h5>
						        <h5>День:</h5>
						        <ul>
								        <li><?php echo (get_post_meta($post->ID, 'title', true)); ?> <?php echo (get_post_meta($post->ID, 'select', true)); ?></li>

						        </ul>
						        <h4>Неделя:</h4>
						        <ul>
								        <li><?php echo (get_post_meta($post->ID, 'title_2', true)); ?> <?php echo (get_post_meta($post->ID, 'select_2', true)); ?></li>

						        </ul>
						        <h4>Месяц:</h4>
						        <ul>
								        <li><?php echo (get_post_meta($post->ID, 'title_3', true)); ?> <?php echo (get_post_meta($post->ID, 'select_3', true)); ?></li>

						        </ul>
				        </div>
		        </div>

        <?php
        endif; }
    wp_reset_postdata();
} ?>

				<!-- Content here -->
		</div>
		</div>
		</div>
		</div>



<?php get_footer(); ?>