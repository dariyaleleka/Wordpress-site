<?php
/**
 * iy-laboratory functions and definitions
 *
 */

add_theme_support( 'post-thumbnails' );

/**
 * Register widget area.
 *
 */

function test_widgets_init() {
    register_sidebar(
        array(
            'name'          => esc_html__( 'Sidebar', 'bookmakers' ),
            'id'            => 'sidebar-1',
            'description'   => esc_html__( 'Add widgets here.', 'bookmakers' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        )
    );
}
add_action( 'widgets_init', 'test_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function test_scripts() {
    wp_enqueue_style( 'test-style', get_stylesheet_uri());
    wp_enqueue_style( 'test-style-one', get_stylesheet_directory_uri() . '/assets/css/index.css', array());
    wp_enqueue_style( 'bootstrap', get_stylesheet_directory_uri() .  '/assets/css/bootstrap.min.css"');
    wp_enqueue_style( 'bootstrap-grid', get_stylesheet_directory_uri() .  '/assets/css/bootstrap-grid.css"');

    wp_enqueue_script( 'test-navigation', get_template_directory_uri() . '/assets/js/index.js');
    wp_enqueue_script( 'bootstrap-js', get_template_directory_uri() .  '/assets/js/bootstrap.min.js', array() );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'test_scripts' );



// This theme uses wp_nav_menu() in one location.
register_nav_menus(
    array(
        'menu-1' => esc_html__( 'Primary', 'test-site' ),
    )
);


/**
 * Register Custom Post Type.
 *
 */

add_action('init', function () {
    $labels = [
        'name' => 'Видео',
        'menu_name' => 'Видео',
        'singular_name' => 'Видео',
        'add_new' => 'Добавить Видео',
        'add_new_item' => 'Добавить новое Видео',
        'edit_item' => 'Редактировать Видео',
        'new_item' => 'Новое Видео',
        'all_items' => 'Все Видео',
        'view_item' => 'Посмотреть Видео',
        'search_items' => 'Найти Видео',
        'not_found' =>  'Ничего не найдено',
        'not_found_in_trash' => 'В корзине не найдено'
    ];
    $args = [
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'menu_position'  => 4,
        'menu_icon'      => 'dashicons-video-alt3',
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'supports' => [
            'title', 'editor', 'thumbnail'
        ],
        'taxonomies' => ['post_lang', 'post_genre'],
       
    ];
    register_post_type('video', $args);
});

/**
 * Register Custom Post Fields for Video.
 *
 */

add_action( 'init', 'true_register_taxonomy_genre' );

function true_register_taxonomy_genre() {

    $args = array(
        'labels' => array(
            'name'                 => 'Жанр',
            'menu_name'                => 'Жанры',
            'singular_name'            => 'Жанр',
            'all_items'                => 'Все Жанры',
            'edit_item'                => 'Изменить Жанр',
            'view_item'                => 'Просмотр Жанров',
            'update_item'              => 'Обновить Жанр',
            'add_new_item'             => 'Добавить новый Жанр',
            'new_item_name'            => 'Название нового Жанра',
            'search_items'             => 'Искать Жанр',
            'popular_items'            => 'Популярные Жанры',
            'separate_items_with_commas' => 'Разделяйте Жанры запятыми',
            'add_or_remove_items'      => 'Добавить или удалить Жанр',
            'choose_from_most_used'    => 'Выбрать из часто используемых Жанров',
            'not_found'                => 'Жанры не найдены',
            'back_to_items'            => '← Назад к Жанрам',
        ),

        $args = array(
            'public' => true,
            'show_in_quick_edit' => true,
            'show_in_menu' => true,
            'show_ui' => false,
            'publicly_queryable' => false,
            'show_in_nav_menus' => true,
//            'meta_box_cb' => true,
            'show_admin_column' => true,
            'hide_empty'    => true,
        )

    );
    register_taxonomy( 'post_genre', 'video', $args );
}

//#2

add_action( 'init', 'true_register_taxonomy_language' );

function true_register_taxonomy_language() {

    $args = array(
        'labels' => array(
            'name'                 => 'Языки',
            'menu_name'                => 'Языки',
            'singular_name'            => 'Язык',
            'all_items'                => 'Все Языки',
            'edit_item'                => 'Изменить Язык',
            'view_item'                => 'Просмотр Языков',
            'update_item'              => 'Обновить Язык',
            'add_new_item'             => 'Добавить новый Язык',
            'new_item_name'            => 'Название нового Языка',
            'search_items'             => 'Искать Язык',
            'popular_items'            => 'Популярные Языки',
            'separate_items_with_commas' => 'Разделяйте Языки запятыми',
            'add_or_remove_items'      => 'Добавить или удалить Язык',
            'choose_from_most_used'    => 'Выбрать из часто используемых Языков',
            'not_found'                => 'Языки не найдены',
            'back_to_items'            => '← Назад к Языкам',
        ),

        $args = array(
            'public' => true,
            'show_in_quick_edit' => true,
            'show_in_menu' => true,
            'show_ui' => false,
            'publicly_queryable' => false,
            'show_in_nav_menus' => true,
//            'meta_box_cb' => true,
            'show_admin_column' => true,
            'hide_empty'    => true,
        )

    );
    register_taxonomy( 'post_lang', 'video', $args );
}



// Числовое поле

function jpen_custom_post_sort($post)
{
    add_meta_box(
        'custom_post_sort_box',
        'Sort',
        'jpen_custom_post_order',
        'video',
        'side'
    );
}

add_action('add_meta_boxes', 'jpen_custom_post_sort');

/* Add a field to the metabox */

function jpen_custom_post_order( $post ) {
    wp_nonce_field( basename( __FILE__ ), 'jpen_custom_post_order_nonce' );
    $current_pos = get_post_meta( $post->ID, '_custom_post_order', true); ?>
		<p><input type="number" name="pos" value="<?php echo $current_pos; ?>" /></p>
    <?php
}

/* Save the input to post_meta_data */
function jpen_save_custom_post_order( $post_id ){
    if ( !isset( $_POST['jpen_custom_post_order_nonce'] ) || !wp_verify_nonce( $_POST['jpen_custom_post_order_nonce'], basename( __FILE__ ) ) ){
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ){
        return;
    }
    if ( ! current_user_can( 'edit_post', $post_id ) ){
        return;
    }
    if ( isset( $_REQUEST['pos'] ) ) {
        update_post_meta( $post_id, '_custom_post_order', sanitize_text_field( $_POST['pos'] ) );
    }
}
add_action( 'save_post', 'jpen_save_custom_post_order' );



/* Add custom post order column to post list */
function jpen_add_custom_post_order_column( $columns ){
    return array_merge ( $columns,
        array( 'pos' => 'Position of post',

		        ));
}
add_filter('manage_video_posts_columns' , 'jpen_add_custom_post_order_column');



/* Display custom post order in the post list */
function jpen_custom_post_order_value( $column, $post_id ){
    if ($column == 'pos' ){
        echo '<p>' . get_post_meta( $post_id, '_custom_post_order', true) . '</p>';
    }
}
add_action( 'manage_posts_custom_column' , 'jpen_custom_post_order_value' , 10 , 2 );


/* Sort posts on the blog posts page according to the custom sort order */
function jpen_custom_post_order_sort( $query ){
    if ( $query->is_main_query() && is_home() ){
        $query->set( 'orderby', 'meta_value' );
        $query->set( 'meta_key', '_custom_post_order' );
        $query->set( 'order' , 'ASC' );
    }
}
add_action( 'pre_get_posts' , 'jpen_custom_post_order_sort' );



// Select

add_action('add_meta_boxes', 'my_extra_fields', 1);

function my_extra_fields() {
    add_meta_box( 'extra_fields', 'Стоимость: ', 'extra_fields_box_func', 'video', 'normal', 'high'  );
}


// код блока
function extra_fields_box_func( $post ){
    ?>
    <div class="main-row-container">
        <div class="post-row">
            <p>
                День:
                <label><input type="text" name="extra[title]" value="<?php echo get_post_meta($post->ID, 'title', 1); ?>"  /> </label>
            </p>

            <p>
                <select name="extra[select]">
                    <?php $sel_v = get_post_meta($post->ID, 'select', 1); ?>
                    <option value="0">Валюта</option>
                    <option value="RUB" <?php selected( $sel_v, 'RUB' )?> >RUB</option>
                    <option value="USD" <?php selected( $sel_v, 'USD' )?> >USD</option>
                    <option value="EUR" <?php selected( $sel_v, 'EUR' )?> >EUR</option>
                </select>
            </p>



        </div>
        <div class="post-row">
            <p>
                Неделя:
                <label><input type="text" name="extra[title_2]" value="<?php echo get_post_meta($post->ID, 'title_2', 1); ?>"  /> </label>
            </p>

            <p>
                <select name="extra[select_2]">
                    <?php $sel_c = get_post_meta($post->ID, 'select_2', 2); ?>
                    <option value="0">Валюта</option>
                    <option value="RUB" <?php selected( $sel_c, 'RUB' )?> >RUB</option>
                    <option value="USD" <?php selected( $sel_c, 'USD' )?> >USD</option>
                    <option value="EUR" <?php selected( $sel_c, 'EUR' )?> >EUR</option>
                </select>
            </p>



        </div>
        <div class="post-row">
            <p>
                Месяц:
                <label><input type="text" name="extra[title_3]" value="<?php echo get_post_meta($post->ID, 'title_3', 1); ?>" /> </label>
            </p>

            <p>
                <select name="extra[select_3]">
                    <?php $sel_d = get_post_meta($post->ID, 'select_3', 3); ?>
                    <option value="0">Валюта</option>
                    <option value="RUB" <?php selected( $sel_d, 'RUB' )?> >RUB</option>
                    <option value="USD" <?php selected( $sel_d, 'USD' )?> >USD</option>
                    <option value="EUR" <?php selected( $sel_d, 'EUR' )?> >EUR</option>
                </select>
            </p>

            <input type="hidden" name="extra_fields_nonce" value="<?php echo wp_create_nonce(__FILE__); ?>" />

        </div>
    </div>
    <?php
}

add_action( 'save_post', 'my_extra_fields_update', 0 );

## Сохраняем данные, при сохранении поста
function my_extra_fields_update( $post_id ){

    if (
        empty( $_POST['extra'] )
        || ! wp_verify_nonce( $_POST['extra_fields_nonce'], __FILE__ )
        || wp_is_post_autosave( $post_id )
        || wp_is_post_revision( $post_id )
    )
        return false;


    $_POST['extra'] = array_map( 'sanitize_text_field', $_POST['extra'] );
    foreach( $_POST['extra'] as $key => $value ){
        if( empty($value) ){
            delete_post_meta( $post_id, $key );
            continue;
        }

        update_post_meta( $post_id, $key, $value );
    }

    return $post_id;
}