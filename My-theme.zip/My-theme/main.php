<?php
/*
Template Name: Шаблон страницы для вывода #1
*/
get_header();

?>


контент 1

<?php get_footer(); ?>